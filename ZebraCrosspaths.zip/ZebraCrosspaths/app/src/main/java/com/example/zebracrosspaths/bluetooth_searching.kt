package com.example.zebracrosspaths

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

@Suppress("CheckReturnValue")
public val bluetooth_searching: ImageVector
  get() {
    if (_bluetooth_searching != null) {
      return _bluetooth_searching!!
    }
    _bluetooth_searching =
      ImageVector.Builder(
          name = "bluetooth_searching",
          defaultWidth = 24.dp,
          defaultHeight = 24.dp,
          viewportWidth = 24f,
          viewportHeight = 24f,
        )
        .apply {
          path(
            fill = SolidColor(Color.Black),
            fillAlpha = 1f,
            stroke = null,
            strokeAlpha = 1f,
            strokeLineWidth = 1f,
            strokeLineCap = StrokeCap.Butt,
            strokeLineJoin = StrokeJoin.Bevel,
            strokeLineMiter = 1f,
            pathFillType = PathFillType.Companion.NonZero,
          ) {
            moveTo(9f, 22f)
            verticalLineTo(14.4f)
            lineTo(4.4f, 19f)
            lineTo(3f, 17.6f)
            lineTo(8.6f, 12f)
            lineTo(3f, 6.4f)
            lineTo(4.4f, 5f)
            lineTo(9f, 9.6f)
            verticalLineTo(2f)
            horizontalLineToRelative(1f)
            lineToRelative(5.7f, 5.7f)
            lineTo(11.4f, 12f)
            lineToRelative(4.3f, 4.3f)
            lineTo(10f, 22f)
            horizontalLineTo(9f)
            close()
            moveTo(11f, 9.6f)
            lineTo(12.9f, 7.7f)
            lineTo(11f, 5.85f)
            verticalLineTo(9.6f)
            close()
            moveToRelative(0f, 8.55f)
            lineTo(12.9f, 16.3f)
            lineTo(11f, 14.4f)
            verticalLineToRelative(3.75f)
            close()
            moveToRelative(5.55f, -3.8f)
            lineTo(14.25f, 12f)
            lineToRelative(2.3f, -2.3f)
            quadToRelative(0.23f, 0.55f, 0.36f, 1.13f)
            reflectiveQuadTo(17.05f, 12f)
            reflectiveQuadToRelative(-0.14f, 1.19f)
            quadToRelative(-0.14f, 0.59f, -0.36f, 1.16f)
            close()
            moveTo(19.5f, 17.2f)
            lineTo(18.25f, 16f)
            quadToRelative(0.5f, -0.93f, 0.78f, -1.94f)
            reflectiveQuadTo(19.3f, 12f)
            reflectiveQuadTo(19.03f, 9.94f)
            quadTo(18.75f, 8.92f, 18.25f, 8f)
            lineTo(19.5f, 6.75f)
            quadToRelative(0.73f, 1.2f, 1.11f, 2.52f)
            reflectiveQuadTo(21f, 12f)
            reflectiveQuadToRelative(-0.39f, 2.71f)
            quadTo(20.23f, 16.02f, 19.5f, 17.2f)
            close()
          }
        }
        .build()
    return _bluetooth_searching!!
  }

private var _bluetooth_searching: ImageVector? = null
