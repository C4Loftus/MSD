package com.example.zebracrosspaths

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

@Suppress("CheckReturnValue")
public val bluetooth_disabled: ImageVector
  get() {
    if (_bluetooth_disabled != null) {
      return _bluetooth_disabled!!
    }
    _bluetooth_disabled =
      ImageVector.Builder(
          name = "bluetooth_disabled",
          defaultWidth = 24.dp,
          defaultHeight = 24.dp,
          viewportWidth = 24f,
          viewportHeight = 24f,
        )
        .apply {
          path(
            fill = SolidColor(Color.Black),
            fillAlpha = 1f,
            stroke = null,
            strokeAlpha = 1f,
            strokeLineWidth = 1f,
            strokeLineCap = StrokeCap.Butt,
            strokeLineJoin = StrokeJoin.Bevel,
            strokeLineMiter = 1f,
            pathFillType = PathFillType.Companion.NonZero,
          ) {
            moveTo(19.8f, 22.6f)
            lineTo(15.6f, 18.4f)
            lineTo(12f, 22f)
            horizontalLineTo(11f)
            verticalLineTo(14.4f)
            lineTo(6.4f, 19f)
            lineTo(5f, 17.6f)
            lineTo(9.9f, 12.7f)
            lineTo(1.4f, 4.2f)
            lineTo(2.8f, 2.8f)
            lineTo(21.2f, 21.2f)
            lineToRelative(-1.4f, 1.4f)
            close()
            moveTo(13f, 18.15f)
            lineTo(14.15f, 17f)
            lineTo(13f, 15.85f)
            verticalLineToRelative(2.3f)
            close()
            moveTo(14.1f, 11.3f)
            lineTo(12.7f, 9.9f)
            lineTo(14.9f, 7.7f)
            lineTo(13f, 5.85f)
            verticalLineTo(10.2f)
            lineToRelative(-2f, -2f)
            verticalLineTo(2f)
            horizontalLineToRelative(1f)
            lineToRelative(5.7f, 5.7f)
            lineToRelative(-3.6f, 3.6f)
            close()
          }
        }
        .build()
    return _bluetooth_disabled!!
  }

private var _bluetooth_disabled: ImageVector? = null
