package com.example.zebracrosspaths


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.tooling.preview.Preview
import com.example.zebracrosspaths.ui.theme.ZebraCrosspathsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZebraCrosspathsTheme {
                //page names
                val items = listOf("Settings", "Logs", "Discover", "Map", "Pr0file")
                //page icons
                val icons = listOf(settings, list, bluetooth_disabled, map, person)
                //current page
                var selected by remember { mutableIntStateOf(0) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        navBar(items, icons, selected, onStateChanged = { selected = it })
                    }//End bottomBar
                ) { innerPadding ->
                    //page selector
                    when (selected) {
                        0 -> settingsPage(Modifier.padding(innerPadding))
                        1 -> logsPage(Modifier.padding(innerPadding))
                        2 -> discoverPage(Modifier.padding(innerPadding))
                        3 -> mapPage(Modifier.padding(innerPadding))
                        4 -> profilePage(Modifier.padding(innerPadding))
                    }//End when
                }//End Scaffold
            }//End ZebraCrosspathsTheme
        }//End setContent
    }//End Override fun onCreate
}//End Class MainActivity

@Composable
fun navBar(items: List<String>, icons: List<ImageVector>, selected: Int, onStateChanged: (Int) -> Unit) {
    NavigationBar {
        items.forEachIndexed { index, item ->
            NavigationBarItem(selected = index == selected, onClick = { onStateChanged(index)}, icon = {
                Column {
                    Icon(imageVector = icons[index], contentDescription = item)
                    Text(item)
                }//End Column
            })//End NavigationBarItem
        }//End Items.forEachIndexed
    }//End NavigationBar
}//End fun navBar

@Composable
fun settingsPage(modifier: Modifier = Modifier) {

    var colour_mode_states by remember { mutableStateOf("dark") }

    Column(modifier = modifier.fillMaxSize()) {
        Text( //title text
            text = "Settings",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
        )//End Text
        Row() {
            Text(
                //light/dark text
                text = "Theme",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
            )//End Text
            Button(onClick = {
                if (colour_mode_states == "light")
                    colour_mode_states = "dark"
                else
                    colour_mode_states = "light"
            }) {
                Text(
                    if (colour_mode_states == "light")
                        "Switch to Dark Mode"
                    else
                        "Switch to Light Mode"
                )
            }//end change theme
        }//End Row

    }//End Column
}//End fun settingsPage

@Composable
fun logsPage(modifier: Modifier = Modifier) {
    Column(modifier = modifier.fillMaxSize()) {
        //page content
    }//End Column
}//End fun logsPage

@Composable
fun discoverPage(modifier: Modifier = Modifier) {
    Column(modifier = modifier.fillMaxSize()) {
        //page content
    }//End Column
}//End fun discoverPage

@Composable
fun mapPage(modifier: Modifier = Modifier) {

    Column(
        modifier = modifier.fillMaxSize()
            .verticalScroll(rememberScrollState()
            )
    ) {

        Text("Explore Map")

        MapScreen(
            modifier = modifier
                .fillMaxWidth()
                .weight(1f)
        )
    }
}

@Composable
fun profilePage(modifier: Modifier = Modifier) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var interests by remember { mutableStateOf("") }

    Column(modifier = modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState()))
    {
        Text( //title text
            text = "Profile",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
        )//End Text

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Name") }
        )//End Name field
        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("description") }
        )//End description field
        OutlinedTextField(
            value = interests,
            onValueChange = { interests = it },
            label = { Text("Interests") }
        )//End Interest field
        musicPreferences()
        sportsPreferences()
        gamePreferences()


    }//End Column
}//End fun profilePage


@Composable
fun musicPreferences() {

    //manages the collapseable menu
    var expanded by remember { mutableStateOf(false) }

    //manages the select genres
    val selectedGenres = remember { mutableStateListOf<String>() }

    //allows users to insert their favourite artists (where they are stored)
    val favouriteArtists = remember { mutableStateListOf<String>() }

    //allows users to insert their favourite artists (where they are typed)
    var artistInput by remember { mutableStateOf("") }

    val genres = listOf(
        "Rock",
        "Pop",
        "Rap",
        "Hip-Hop",
        "Metal",
        "Indie",
        "Electronic",
        "Country",
        "Jazz",
        "Classical"
    )//End genres

    Column(modifier = Modifier.fillMaxWidth()) {

        //allows to expand and collapse the list
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = "Music Preferences",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )//End heading text

            //arrow changes depending on state
            Text(
                text = if (expanded) "▲" else "▼"
            )//end arrow text
        }

        //Only display when expanded
        if (expanded) {

            Text("Select your favourite genres:")

            //selection for genre with foreach
            genres.forEach { genre ->

                //Uses a filterchip (similar to checkbox) for genre
                FilterChip(
                    selected = genre in selectedGenres,
                    onClick = {
                        if (genre in selectedGenres) {
                            selectedGenres.remove(genre)
                        } else {
                            selectedGenres.add(genre)
                        }
                    },//end onclick
                    label = { Text(genre) }
                )//End filter chip
            }//end for each

            //list of favourite artists
            Text(
                text = "Favourite Artists / Bands",
                fontWeight = FontWeight.Bold
            )

            //Input field
            OutlinedTextField(
                value = artistInput,
                onValueChange = { artistInput = it },
                label = { Text("Enter an artist or band") }
            )

            //Button adds artist. (error check and trims extra white space)
            Button(
                onClick = {
                    if (artistInput.isNotBlank()) {
                        favouriteArtists.add(artistInput.trim())
                        artistInput = ""
                    }//end if
                }//end on click
            ) {
                Text("Add Artist")
            }//end button

            //displays the list of favourite artists
            favouriteArtists.forEach { artist ->
                Text("• $artist")
            }//end favourite artists
        }//End If
    }//End Column
}//End musicpreference

@Composable
fun sportsPreferences() {

    //manages the collapseable menu
    var expanded by remember { mutableStateOf(false) }

    //manages the select sports
    val selectedSports = remember { mutableStateListOf<String>() }

    //allows users to insert their favourite teams (where they are stored)
    val favouriteTeams = remember { mutableStateListOf<String>() }

    //allows users to insert their favourite artists (where they are typed)
    var sportInput by remember { mutableStateOf("") }

    val sports = listOf(
        "Football",
        "Rugby",
        "Hurling",
        "Camogie",
        "GAA",
        "Basketball",
        "Tennis",
        "Badminton",
        "Volleyball",
        "Golf"
    )//End sports

    Column(modifier = Modifier.fillMaxWidth()) {

        //allows to expand and collapse the list
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = "Sports Preferences",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )//End heading text

            //arrow changes depending on state
            Text(
                text = if (expanded) "▲" else "▼"
            )//end arrow text
        }

        //Only display when expanded
        if (expanded) {

            Text("Select your favourite sports:")

            //selection for sports with foreach
            sports.forEach { sports ->

                //Uses a filterchip (similar to checkbox) for sports
                FilterChip(
                    selected = sports in selectedSports,
                    onClick = {
                        if (sports in selectedSports) {
                            selectedSports.remove(sports)
                        } else {
                            selectedSports.add(sports)
                        }
                    },//end onclick
                    label = { Text(sports) }
                )//End filter chip
            }//end for each

            //list of favourite teams
            Text(
                text = "Favourite Teams",
                fontWeight = FontWeight.Bold
            )

            //Input field
            OutlinedTextField(
                value = sportInput,
                onValueChange = { sportInput = it },
                label = { Text("Enter a sports team") }
            )

            //Button adds aports team. (error check and trims extra white space)
            Button(
                onClick = {
                    if (sportInput.isNotBlank()) {
                        favouriteTeams.add(sportInput.trim())
                        sportInput = ""
                    }//end if
                }//end on click
            ) {
                Text("Add Team")
            }//end button

            //displays the list of favourite teams
            favouriteTeams.forEach { team ->
                Text("• $team")
            }//end favourite Teams
        }//End If
    }//End Column
}//End sportsPreferences()

@Composable
fun moviePreferences() {

    //manages the collapseable menu
    var expanded by remember { mutableStateOf(false) }

    //manages the selected genres
    val selectedGenres = remember { mutableStateListOf<String>() }

    //allows users to insert their favourite movies (where they are stored)
    val favouriteMovies = remember { mutableStateListOf<String>() }

    //allows users to insert their favourite movies (where they are typed)
    var movieInput by remember { mutableStateOf("") }

    val genres = listOf(
        "Action",
        "Romance",
        "Science Fiction",
        "Animated",
        "Documentary",
        "Horror",
        "Comedy",
    )//End genres

    Column(modifier = Modifier.fillMaxWidth()) {

        //allows to expand and collapse the list
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = "Movie Preferences",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )//End heading text

            //arrow changes depending on state
            Text(
                text = if (expanded) "▲" else "▼"
            )//end arrow text
        }

        //Only display when expanded
        if (expanded) {

            Text("Select your favourite genres")

            //selection for genres with foreach
            genres.forEach { genre ->

                //Uses a filterchip (similar to checkbox) for genre
                FilterChip(
                    selected = genre in selectedGenres,
                    onClick = {
                        if (genre in selectedGenres) {
                            selectedGenres.remove(genre)
                        } else {
                            selectedGenres.add(genre)
                        }
                    },//end onclick
                    label = { Text(genre) }
                )//End filter chip
            }//end for each

            //list of favourite movies
            Text(
                text = "Favourite Movies",
                fontWeight = FontWeight.Bold
            )

            //Input field
            OutlinedTextField(
                value = movieInput,
                onValueChange = { movieInput = it },
                label = { Text("Enter a movie:") }
            )

            //Button adds movie . (error check and trims extra white space)
            Button(
                onClick = {
                    if (movieInput.isNotBlank()) {
                        favouriteMovies.add(movieInput.trim())
                        movieInput = ""
                    }//end if
                }//end on click
            ) {
                Text("Add Movie")
            }//end button

            //displays the list of favourite teams
            favouriteMovies.forEach { movie ->
                Text("• $movie")
            }//end favouriteMovies
        }//End If
    }//End Column
}//End moviePreferences()

@Composable
fun gamePreferences() {

    //manages the collapsable menu
    var expanded by remember { mutableStateOf(false) }

    //manages the select genres
    val selectedGenres = remember { mutableStateListOf<String>() }

    //allows users to insert their favourite games (where they are stored)
    val favouriteGames = remember { mutableStateListOf<String>() }

    //allows users to insert their favourite game (where they are typed)
    var gameInput by remember { mutableStateOf("") }

    val genres = listOf(
        "Board Games",
        "Card Games",
        "Horror Games",
        "Shooter Games",
        "Puzzle Games",
        "Story Games",
        "Cozy Games",
        "Role Playing Games",
        "Turn Based Games",
        "Tactics Games"
    )//End genres

    Column(modifier = Modifier.fillMaxWidth()) {

        //allows to expand and collapse the list
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = "Game Preferences",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )//End heading text

            //arrow changes depending on state
            Text(
                text = if (expanded) "▲" else "▼"
            )//end arrow text
        }

        //Only display when expanded
        if (expanded) {

            Text("Select your favourite game genres:")

            //selection for genre with foreach
            genres.forEach { genre ->

                //Uses a filterchip (similar to checkbox) for genre
                FilterChip(
                    selected = genre in selectedGenres,
                    onClick = {
                        if (genre in selectedGenres) {
                            selectedGenres.remove(genre)
                        } else {
                            selectedGenres.add(genre)
                        }
                    },//end onclick
                    label = { Text(genre) }
                )//End filter chip
            }//end for each

            //list of favourite games
            Text(
                text = "Favourite Games",
                fontWeight = FontWeight.Bold
            )

            //Input field
            OutlinedTextField(
                value = gameInput,
                onValueChange = { gameInput = it },
                label = { Text("Enter a game") }
            )

            //Button adds games. (error check and trims extra white space)
            Button(
                onClick = {
                    if (gameInput.isNotBlank()) {
                        favouriteGames.add(gameInput.trim())
                        gameInput = ""
                    }//end if
                }//end on click
            ) {
                Text("Add Games")
            }//end button

            //displays the list of favourite games
            favouriteGames.forEach { games ->
                Text("• $games")
            }//end favourite games
        }//End If
    }//End Column
}//End GamePreference
