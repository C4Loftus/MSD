
package com.example.icetomeetyou

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.Room
import com.example.icetomeetyou.databases.AppDatabase
import com.example.icetomeetyou.databases.User
import kotlinx.coroutines.launch

@Composable
fun profilePage(modifier: Modifier = Modifier) {

    // Gets the Android context needed to access the database
    val context = LocalContext.current

    // Creates a coroutine scope for running database operations
    val scope = rememberCoroutineScope()

    // Opens the local Room database
    val database = remember {
        Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "user_database"
        )
            // Allows the database to reset if its structure changes (testing only)
            .fallbackToDestructiveMigration(dropAllTables = true)
            .build()
    }//End val database = remember

    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var interests by remember { mutableStateOf("") }

    val musicGenres = remember { mutableStateListOf<String>() }
    val favouriteArtists = remember { mutableStateListOf<String>() }

    val sports = remember { mutableStateListOf<String>() }
    val favouriteTeams = remember { mutableStateListOf<String>() }

    val movieGenres = remember { mutableStateListOf<String>() }
    val favouriteMovies = remember { mutableStateListOf<String>() }

    val gameGenres = remember { mutableStateListOf<String>() }
    val favouriteGames = remember { mutableStateListOf<String>() }

    //checks whether the user can edit their profile
    var isEditing by remember { mutableStateOf(false) }

    //checks whether the profile is currently loading from the database
    var isLoading by remember { mutableStateOf(true) }

    //checks whether the profile is currently being saved
    var isSaving by remember { mutableStateOf(false) }

    //checks messages such as successful saves or errors
    var status by remember { mutableStateOf("") }

    //when the page opens runs and loads dataabase
    LaunchedEffect(database) {
        try {

            //gets user id 1 (will always be the local user)
            val user = database.UserDao().getUser(1)

            //if a saved user exists load their profile
            if (user != null) {

                name = user.name
                description = user.description
                interests = user.interests

                musicGenres.clear()
                musicGenres.addAll(user.musicGenres)
                favouriteArtists.clear()
                favouriteArtists.addAll(user.favouriteArtists)

                sports.clear()
                sports.addAll(user.sports)
                favouriteTeams.clear()
                favouriteTeams.addAll(user.favouriteTeams)

                movieGenres.clear()
                movieGenres.addAll(user.movieGenres)
                favouriteMovies.clear()
                favouriteMovies.addAll(user.favouriteMovies)

                gameGenres.clear()
                gameGenres.addAll(user.gameGenres)
                favouriteGames.clear()
                favouriteGames.addAll(user.favouriteGames)

                //Disables editing because the saved profile is being displayed
                isEditing = false

            }//end if
            else {

                // Enables editing if no profile has been saved yet
                isEditing = true

            }//else

        }//end try
        catch (e: Exception) {

            status = "Could not load profile: ${e.message}"

        }//end catch
        finally {

            //Loading is finished whether it succeeded or failed
            isLoading = false

        }//end finally
    }//end launch effect

    //layout
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {

        Text("Profile", fontSize = 30.sp, fontWeight = FontWeight.Bold)

        ProfilePicture()

        //a loading message while retrieving the profile
        if (isLoading) {
            Text("Loading profile...")
        }//end if loading
        else {

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Name") },
                enabled = isEditing
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                enabled = isEditing
            )

            OutlinedTextField(
                value = interests,
                onValueChange = { interests = it },
                label = { Text("Interests") },
                enabled = isEditing
            )

            musicPreferences(musicGenres, favouriteArtists, isEditing)
            sportsPreferences(sports, favouriteTeams, isEditing)
            moviePreferences(movieGenres, favouriteMovies, isEditing)
            gamePreferences(gameGenres, favouriteGames, isEditing)

            //button switches between editing and submitting the profile
            Button(

                //prevents pressing the button while data is being saved
                enabled = !isSaving,

                onClick = {

                    //if not editing, enable editing when the button is pressed
                    if (!isEditing) {
                        isEditing = true
                        status = ""
                    }//end if

                    // Prevents saving a profile without a name
                    else if (name.isBlank()) {
                        status = "Please enter a name."
                    }//end else if

                    // If editing and the name is valid, save the profile
                    else {

                        // Marks the profile as currently saving
                        isSaving = true

                        // Runs database operations in a coroutine
                        scope.launch {
                            try {

                                //Creates a User object using the current profile information
                                val user = User(

                                    // Uses ID 1 because there is only one local profile for now
                                    userId = 1,

                                    // Saves basic profile information
                                    name = name.trim(),
                                    description = description,
                                    interests = interests,

                                    //changes the preferences into regular lists
                                    musicGenres = musicGenres.toList(),
                                    favouriteArtists = favouriteArtists.toList(),
                                    sports = sports.toList(),
                                    favouriteTeams = favouriteTeams.toList(),
                                    movieGenres = movieGenres.toList(),
                                    favouriteMovies = favouriteMovies.toList(),
                                    gameGenres = gameGenres.toList(),
                                    favouriteGames = favouriteGames.toList()

                                )//end user = User

                                // Checks whether the user already exists in the database
                                if (database.UserDao().getUser(1) == null) {

                                    // Inserts a new user if none exists
                                    database.UserDao().insertUser(user)

                                }//end if
                                else {

                                    // Updates the existing user instead of creating another
                                    database.UserDao().updateUser(user)

                                }//end else

                                // Disables editing after successfully saving
                                isEditing = false

                                // Displays a successful save message
                                status = "Profile saved!"

                            }//end try
                            catch (e: Exception) {

                                // Displays an error if saving fails
                                status = "Could not save profile: ${e.message}"

                            }//end catch
                            finally {

                                // Allows the button to be pressed again once saving finishes
                                isSaving = false

                            }//end finally
                        }
                    }//end else
                }//end on click
            ) {

                // Changes the button text depending on its current state
                Text(
                    if (isSaving) "Saving..."
                    else if (isEditing) "Submit Profile"
                    else "Edit Profile"
                )

            }//End button

            // Displays any save confirmation or error message
            if (status.isNotEmpty()) Text(status)

        }//end else
    }//end column
}//end fun profile page
