package com.example.icetomeetyou

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

@Composable
fun musicPreferences(
    selectedGenres: MutableList<String>,
    favouriteArtists: MutableList<String>,
    isEditing: Boolean
) {

    //manages the collapseable menu
    var expanded by remember { mutableStateOf(false) }

    //manages the select genres

    //allows users to insert their favourite artists (where they are stored)

    //allows users to insert their favourite artists (where they are typed)
    var artistInput by remember { mutableStateOf("") }

    val genres = listOf(
        "Rock",
        "Pop",
        "Rap",
        "Hip-Hop",
        "Metal",
        "Indie",
        "Electronic",
        "Country",
        "Jazz",
        "Classical"
    )//End genres

    Column(modifier = Modifier.fillMaxWidth()) {

        //allows to expand and collapse the list
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = "Music Preferences",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )//End heading text

            //arrow changes depending on state
            Text(
                text = if (expanded) "▲" else "▼"
            )//end arrow text
        }

        //Only display when expanded
        if (expanded) {

            Text("Select your favourite genres:")

            //selection for genre with foreach
            genres.forEach { genre ->

                //Uses a filterchip (similar to checkbox) for genre
                FilterChip(
                    enabled = isEditing,
                    selected = genre in selectedGenres,
                    onClick = {
                        if (genre in selectedGenres) {
                            selectedGenres.remove(genre)
                        } else {
                            selectedGenres.add(genre)
                        }
                    },//end onclick
                    label = { Text(genre) }
                )//End filter chip
            }//end for each

            //list of favourite artists
            Text(
                text = "Favourite Artists / Bands",
                fontWeight = FontWeight.Bold
            )

            //Input field
            OutlinedTextField(
                enabled = isEditing,
                value = artistInput,
                onValueChange = { artistInput = it },
                label = { Text("Enter an artist or band") }
            )

            //Button adds artist. (error check and trims extra white space)
            Button(
                enabled = isEditing,
                onClick = {
                    if (artistInput.isNotBlank()) {
                        favouriteArtists.add(artistInput.trim())
                        artistInput = ""
                    }//end if
                }//end on click
            ) {
                Text("Add Artist")
            }//end button

            //displays the list of favourite artists
            favouriteArtists.forEach { artist ->
                Text("• $artist")
            }//end favourite artists
        }//End If
    }//End Column
}//End musicpreference