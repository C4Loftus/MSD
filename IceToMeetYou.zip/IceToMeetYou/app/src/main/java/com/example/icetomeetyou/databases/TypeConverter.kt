package com.example.icetomeetyou.databases

import androidx.room.TypeConverter

//Due to room not supporting lists. This converts the lists from filterchip to a string to be stored and vise versa
class Converters {

    @TypeConverter
    fun fromList(value: List<String>): String {
        return value.joinToString(",")
    }//end fromList

    @TypeConverter
    fun toList(value: String): List<String> {
        if (value.isEmpty()) {
            return emptyList()
        }

        return value.split(",")
    }//end toList
}//End converter