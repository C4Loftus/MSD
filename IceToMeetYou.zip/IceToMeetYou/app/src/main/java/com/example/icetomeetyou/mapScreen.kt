package com.example.icetomeetyou

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import org.maplibre.compose.map.MaplibreMap
import org.maplibre.compose.map.rememberMapState
import org.maplibre.compose.style.BaseStyle

@Composable
fun MapScreen(modifier: Modifier = Modifier) {

    val mapState = rememberMapState(
        baseStyle = BaseStyle.Uri(
            "https://tiles.openfreemap.org/styles/liberty"
        )
    )

    MaplibreMap(
        modifier = modifier,
        state = mapState
    )
}
