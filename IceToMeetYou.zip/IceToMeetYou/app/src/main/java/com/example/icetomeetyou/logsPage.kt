package com.example.icetomeetyou

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.room.Room
import com.example.icetomeetyou.databases.AppDatabase
import com.example.icetomeetyou.databases.User
import kotlinx.coroutines.launch

@Composable
fun logsPage(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val database = remember {
        Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "user_database" // SAME database as the profile page
        )
            .fallbackToDestructiveMigration(dropAllTables = true) // Testing only
            .build()
    }//end val database = remember

    var users by remember { mutableStateOf<List<User>>(emptyList()) }
    var error by remember { mutableStateOf("") }

    // Reload when the Logs tab is opened.
    LaunchedEffect(database) {
        try {
            users = database.UserDao().getAllUsers()
        }//end try
        catch (e: Exception) {
            error = "Could not read database: ${e.message}"
        }//end catch
    }//end launched effect

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("User Database (Testing)")
        Button(onClick = {
            scope.launch {
                try {
                    users = database.UserDao().getAllUsers()
                    error = ""
                }//end try
                catch (e: Exception) {
                    error = "Could not read database: ${e.message}"
                }//end catch
            }//end scope.launch
        }//end on click
        )//end button()
        {
            Text("Refresh Users")
        }//end button { }

        if (error.isNotEmpty()) Text(error)
        if (users.isEmpty() && error.isEmpty()) Text("No users saved yet.")
        users.forEach { user ->
            Text("User ID: ${user.userId}")
            Text("Name: ${user.name}")
            Text("Description: ${user.description}")
            Text("Interests: ${user.interests}")
            Text("Music Genres: ${user.musicGenres.joinToString()}")
            Text("Favourite Artists: ${user.favouriteArtists.joinToString()}")
            Text("Sports: ${user.sports.joinToString()}")
            Text("Favourite Teams: ${user.favouriteTeams.joinToString()}")
            Text("Movie Genres: ${user.movieGenres.joinToString()}")
            Text("Favourite Movies: ${user.favouriteMovies.joinToString()}")
            Text("Game Genres: ${user.gameGenres.joinToString()}")
            Text("Favourite Games: ${user.favouriteGames.joinToString()}")
            Text("------------------------")
        }//end if
    }//end  column
}//end logs page