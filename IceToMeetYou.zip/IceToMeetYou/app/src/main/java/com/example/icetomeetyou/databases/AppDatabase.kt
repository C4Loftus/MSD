package com.example.icetomeetyou.databases

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters


@Database(
    entities = [User::class],
    version = 2
)//End Database
@TypeConverters(Converters::class)//End Typeconvert

abstract class AppDatabase : RoomDatabase() {

    abstract fun UserDao(): UserDao
}//abstract AppDatabase