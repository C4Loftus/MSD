package com.example.icetomeetyou

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

@Composable
fun moviePreferences(
    selectedGenres: MutableList<String>,
    favouriteMovies: MutableList<String>,
    isEditing: Boolean
) {

    //manages the collapseable menu
    var expanded by remember { mutableStateOf(false) }

    //manages the selected genres

    //allows users to insert their favourite movies (where they are stored)

    //allows users to insert their favourite movies (where they are typed)
    var movieInput by remember { mutableStateOf("") }

    val genres = listOf(
        "Action",
        "Romance",
        "Science Fiction",
        "Animated",
        "Documentary",
        "Horror",
        "Comedy",
    )//End genres

    Column(modifier = Modifier.fillMaxWidth()) {

        //allows to expand and collapse the list
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = "Movie Preferences",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )//End heading text

            //arrow changes depending on state
            Text(
                text = if (expanded) "▲" else "▼"
            )//end arrow text
        }

        //Only display when expanded
        if (expanded) {

            Text("Select your favourite genres")

            //selection for genres with foreach
            genres.forEach { genre ->

                //Uses a filterchip (similar to checkbox) for genre
                FilterChip(
                    enabled = isEditing,
                    selected = genre in selectedGenres,
                    onClick = {
                        if (genre in selectedGenres) {
                            selectedGenres.remove(genre)
                        } else {
                            selectedGenres.add(genre)
                        }
                    },//end onclick
                    label = { Text(genre) }
                )//End filter chip
            }//end for each

            //list of favourite movies
            Text(
                text = "Favourite Movies",
                fontWeight = FontWeight.Bold
            )

            //Input field
            OutlinedTextField(
                enabled = isEditing,
                value = movieInput,
                onValueChange = { movieInput = it },
                label = { Text("Enter a movie:") }
            )

            //Button adds movie . (error check and trims extra white space)
            Button(
                enabled = isEditing,
                onClick = {
                    if (movieInput.isNotBlank()) {
                        favouriteMovies.add(movieInput.trim())
                        movieInput = ""
                    }//end if
                }//end on click
            ) {
                Text("Add Movie")
            }//end button

            //displays the list of favourite teams
            favouriteMovies.forEach { movie ->
                Text("• $movie")
            }//end favouriteMovies
        }//End If
    }//End Column
}//End moviePreferences()