package com.example.icetomeetyou

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

@Composable
fun settingsPage(modifier: Modifier = Modifier.Companion) {

    var colour_mode_states by remember { mutableStateOf("dark") }

    Column(modifier = modifier.fillMaxSize()) {
        Text(
            //title text
            text = "Settings",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
        )//End Text
        Row() {
            Text(
                //light/dark text
                text = "Theme",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
            )//End Text
            Button(onClick = {
                if (colour_mode_states == "light")
                    colour_mode_states = "dark"
                else
                    colour_mode_states = "light"
            }) {
                Text(
                    if (colour_mode_states == "light")
                        "Switch to Dark Mode"
                    else
                        "Switch to Light Mode"
                )
            }//end change theme
        }//End Row

    }//End Column
}//End fun settingsPage