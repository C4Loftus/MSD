package com.example.icetomeetyou

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy

@Composable
fun discoverPage(modifier: Modifier = Modifier) {

    val context = LocalContext.current
    val client = remember { Nearby.getConnectionsClient(context.applicationContext) }

    // Keep the same service ID as your Testapp so the two apps can discover one another.
    val serviceId = "com.example.nearbytest.SERVICE"
    val strategy = Strategy.P2P_CLUSTER
    val myName = remember { "User-${(1000..9999).random()}" }

    // Screen information and chat messages.
    var running by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Not discoverable. You are $myName") }
    var message by remember { mutableStateOf("") }
    val chatMessages = remember { mutableStateListOf<String>() }

    // Track discovered, connected and pending devices.
    val knownNames = remember { mutableStateMapOf<String, String>() }
    val connected = remember { mutableStateMapOf<String, String>() }
    val pending = remember { mutableSetOf<String>() }

    fun updateStatus() {
        status = "You are $myName. Nearby: ${knownNames.size}, connected: ${connected.size}"
    }

    fun stopNearby() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        knownNames.clear()
        connected.clear()
        pending.clear()
        running = false
        status = "Stopped. You are $myName"
    }

    // Receive messages sent by another phone.
    val payloadCallback = remember {
        object : PayloadCallback() {
            override fun onPayloadReceived(endpointId: String, payload: Payload) {
                if (payload.type == Payload.Type.BYTES) {
                    val text = payload.asBytes()?.toString(Charsets.UTF_8) ?: return
                    chatMessages.add("${connected[endpointId] ?: endpointId}: $text")
                }
            }

            override fun onPayloadTransferUpdate(
                endpointId: String,
                update: PayloadTransferUpdate
            ) {
            }
        }
    }

    // Accept connections and report when someone joins or leaves.
    val connectionCallback = remember {
        object : ConnectionLifecycleCallback() {
            override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
                knownNames[endpointId] = info.endpointName

                // Automatically accepts connections for this test only.
                client.acceptConnection(endpointId, payloadCallback)
                    .addOnFailureListener { error ->
                        chatMessages.add("[system] Could not accept connection: ${error.message}")
                    }
            }

            override fun onConnectionResult(
                endpointId: String,
                result: ConnectionResolution
            ) {
                pending.remove(endpointId)
                val name = knownNames[endpointId] ?: endpointId

                if (result.status.isSuccess) {
                    connected[endpointId] = name
                    chatMessages.add("[system] $name joined the chat")
                } else {
                    chatMessages.add("[system] Connection to $name failed")
                }
                updateStatus()
            }

            override fun onDisconnected(endpointId: String) {
                val name = connected.remove(endpointId) ?: knownNames[endpointId] ?: endpointId
                chatMessages.add("[system] $name disconnected")
                updateStatus()
            }
        }
    }

    // Find other phones running the same Nearby Connections service.
    val discoveryCallback = remember {
        object : EndpointDiscoveryCallback() {
            override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
                knownNames[endpointId] = info.endpointName
                chatMessages.add("[system] Found ${info.endpointName}")
                updateStatus()

                // Only one phone requests the connection, avoiding duplicate requests.
                if (myName < info.endpointName &&
                    endpointId !in connected && endpointId !in pending
                ) {
                    pending.add(endpointId)
                    client.requestConnection(myName, endpointId, connectionCallback)
                        .addOnFailureListener { error ->
                            pending.remove(endpointId)
                            chatMessages.add("[system] Connection request failed: ${error.message}")
                        }
                }
            }

            override fun onEndpointLost(endpointId: String) {
                knownNames.remove(endpointId)
                pending.remove(endpointId)
                updateStatus()
            }
        }
    }

    // Start advertising our phone and searching for other phones.
    fun startNearby() {
        if (running) return
        running = true
        status = "Starting Nearby Connections..."

        client.startAdvertising(
            myName,
            serviceId,
            connectionCallback,
            AdvertisingOptions.Builder().setStrategy(strategy).build()
        ).addOnSuccessListener {
            updateStatus()
        }.addOnFailureListener { error ->
            stopNearby()
            status = "Advertising failed: ${error.message}"
        }

        client.startDiscovery(
            serviceId,
            discoveryCallback,
            DiscoveryOptions.Builder().setStrategy(strategy).build()
        ).addOnFailureListener { error ->
            stopNearby()
            status = "Discovery failed: ${error.message}"
        }
    }

    // Ask for Android permissions when the user presses Start.
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (nearbyPermissions().all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }) {
            startNearby()
        } else {
            val denied =
                results.filterValues { !it }.keys.joinToString { it.substringAfterLast('.') }
            status = "Permissions denied: $denied"
        }
    }

    // Stop scanning and disconnect when the Discover page is closed.
    DisposableEffect(client) {
        onDispose {
            client.stopAdvertising()
            client.stopDiscovery()
            client.stopAllEndpoints()
        }
    }

    val listState = rememberLazyListState()
    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) listState.animateScrollToItem(chatMessages.lastIndex)
    }

    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Nearby Connections Test")

        Button(onClick = {
            if (running) {
                stopNearby()
            } else {
                val permissions = nearbyPermissions()
                if (permissions.all {
                        ContextCompat.checkSelfPermission(
                            context,
                            it
                        ) == PackageManager.PERMISSION_GRANTED
                    }) {
                    startNearby()
                } else {
                    permissionLauncher.launch(permissions)
                }
            }
        }) {
            Text(if (running) "Stop" else "Become discoverable")
        }

        Text(status)

        // Messages and connection updates appear here.
        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            state = listState
        ) {
            items(chatMessages) { line -> Text(line) }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = message,
                onValueChange = { message = it },
                label = { Text("Message") },
                modifier = Modifier.weight(1f),
                maxLines = 3
            )

            Button(
                enabled = connected.isNotEmpty() && message.isNotBlank(),
                onClick = {
                    val text = message.trim()
                    client.sendPayload(
                        connected.keys.toList(),
                        Payload.fromBytes(text.toByteArray(Charsets.UTF_8))
                    ).addOnSuccessListener {
                        chatMessages.add("Me: $text")
                    }.addOnFailureListener { error ->
                        chatMessages.add("[system] Send failed: ${error.message}")
                    }
                    message = ""
                }
            ) {
                Text("Send")
            }
        }
    }
}


// Runtime permissions needed on each Android version.
private fun nearbyPermissions(): Array<String> {
    val permissions = mutableListOf<String>()

    if (Build.VERSION.SDK_INT >= 31) {
        permissions.add(Manifest.permission.BLUETOOTH_SCAN)
        permissions.add(Manifest.permission.BLUETOOTH_ADVERTISE)
        permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
    }

    if (Build.VERSION.SDK_INT <= 32) {
        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 29) {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    if (Build.VERSION.SDK_INT >= 33) {
        permissions.add(Manifest.permission.NEARBY_WIFI_DEVICES)
    }

    if (Build.VERSION.SDK_INT >= 37) {
        permissions.add(Manifest.permission.ACCESS_LOCAL_NETWORK)
    }

    return permissions.toTypedArray()
}
