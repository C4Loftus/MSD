package com.example.icetomeetyou

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

@Composable
fun gamePreferences(
    selectedGenres: MutableList<String>,
    favouriteGames: MutableList<String>,
    isEditing: Boolean
) {

    //manages the collapsable menu
    var expanded by remember { mutableStateOf(false) }

    //manages the select genres

    //allows users to insert their favourite games (where they are stored)

    //allows users to insert their favourite game (where they are typed)
    var gameInput by remember { mutableStateOf("") }

    val genres = listOf(
        "Board Games",
        "Card Games",
        "Horror Games",
        "Shooter Games",
        "Puzzle Games",
        "Story Games",
        "Cozy Games",
        "Role Playing Games",
        "Turn Based Games",
        "Tactics Games"
    )//End genres

    Column(modifier = Modifier.fillMaxWidth()) {

        //allows to expand and collapse the list
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = "Game Preferences",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )//End heading text

            //arrow changes depending on state
            Text(
                text = if (expanded) "▲" else "▼"
            )//end arrow text
        }

        //Only display when expanded
        if (expanded) {

            Text("Select your favourite game genres:")

            //selection for genre with foreach
            genres.forEach { genre ->

                //Uses a filterchip (similar to checkbox) for genre
                FilterChip(
                    enabled = isEditing,
                    selected = genre in selectedGenres,
                    onClick = {
                        if (genre in selectedGenres) {
                            selectedGenres.remove(genre)
                        } else {
                            selectedGenres.add(genre)
                        }
                    },//end onclick
                    label = { Text(genre) }
                )//End filter chip
            }//end for each

            //list of favourite games
            Text(
                text = "Favourite Games",
                fontWeight = FontWeight.Bold
            )

            //Input field
            OutlinedTextField(
                enabled = isEditing,
                value = gameInput,
                onValueChange = { gameInput = it },
                label = { Text("Enter a game") }
            )

            //Button adds games. (error check and trims extra white space)
            Button(
                enabled = isEditing,
                onClick = {
                    if (gameInput.isNotBlank()) {
                        favouriteGames.add(gameInput.trim())
                        gameInput = ""
                    }//end if
                }//end on click
            ) {
                Text("Add Games")
            }//end button

            //displays the list of favourite games
            favouriteGames.forEach { games ->
                Text("• $games")
            }//end favourite games
        }//End If
    }//End Column
}//End GamePreference