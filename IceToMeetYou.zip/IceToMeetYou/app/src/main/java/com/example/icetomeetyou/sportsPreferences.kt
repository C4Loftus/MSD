package com.example.icetomeetyou

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

@Composable
fun sportsPreferences(
    selectedSports: MutableList<String>,
    favouriteTeams: MutableList<String>,
    isEditing: Boolean
) {

    //manages the collapseable menu
    var expanded by remember { mutableStateOf(false) }

    //manages the select sports

    //allows users to insert their favourite teams (where they are stored)

    //allows users to insert their favourite artists (where they are typed)
    var sportInput by remember { mutableStateOf("") }

    val sports = listOf(
        "Football",
        "Rugby",
        "Hurling",
        "Camogie",
        "GAA",
        "Basketball",
        "Tennis",
        "Badminton",
        "Volleyball",
        "Golf"
    )//End sports

    Column(modifier = Modifier.fillMaxWidth()) {

        //allows to expand and collapse the list
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = "Sports Preferences",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )//End heading text

            //arrow changes depending on state
            Text(
                text = if (expanded) "▲" else "▼"
            )//end arrow text
        }

        //Only display when expanded
        if (expanded) {

            Text("Select your favourite sports:")

            //selection for sports with foreach
            sports.forEach { sports ->

                //Uses a filterchip (similar to checkbox) for sports
                FilterChip(
                    enabled = isEditing,
                    selected = sports in selectedSports,
                    onClick = {
                        if (sports in selectedSports) {
                            selectedSports.remove(sports)
                        } else {
                            selectedSports.add(sports)
                        }
                    },//end onclick
                    label = { Text(sports) }
                )//End filter chip
            }//end for each

            //list of favourite teams
            Text(
                text = "Favourite Teams",
                fontWeight = FontWeight.Bold
            )

            //Input field
            OutlinedTextField(
                enabled = isEditing,
                value = sportInput,
                onValueChange = { sportInput = it },
                label = { Text("Enter a sports team") }
            )

            //Button adds aports team. (error check and trims extra white space)
            Button(
                enabled = isEditing,
                onClick = {
                    if (sportInput.isNotBlank()) {
                        favouriteTeams.add(sportInput.trim())
                        sportInput = ""
                    }//end if
                }//end on click
            ) {
                Text("Add Team")
            }//end button

            //displays the list of favourite teams
            favouriteTeams.forEach { team ->
                Text("• $team")
            }//end favourite Teams
        }//End If
    }//End Column
}//End sportsPreferences()