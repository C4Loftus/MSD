package com.example.icetomeetyou.databases

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface UserDao {

    @Insert
    suspend fun insertUser(user: User)

    @Update
    suspend fun updateUser(user: User)

    @Query("SELECT * FROM User WHERE userId = :id")
    suspend fun getUser(id: Int): User?

    @Query("SELECT * FROM User")
    suspend fun getAllUsers(): List<User>

    @Query("DELETE FROM User WHERE userId = :id")
    suspend fun deleteUser(id: Int)
}//End UserDao