package com.example.icetomeetyou


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.icetomeetyou.ui.theme.ZebraCrosspathsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZebraCrosspathsTheme {
                //page names
                val items = listOf("Settings", "Logs", "Discover", "Map", "Pr0file")
                //page icons
                val icons = listOf(settings, list, bluetooth_disabled, map, person)
                //current page
                var selected by remember { mutableIntStateOf(0) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        navBar(items, icons, selected, onStateChanged = { selected = it })
                    }//End bottomBar
                ) { innerPadding ->
                    //page selector
                    when (selected) {
                        0 -> settingsPage(Modifier.padding(innerPadding))
                        1 -> logsPage(Modifier.padding(innerPadding))
                        2 -> discoverPage(Modifier.padding(innerPadding))
                        3 -> mapPage(Modifier.padding(innerPadding))
                        4 -> profilePage(Modifier.padding(innerPadding))
                    }//End when
                }//End Scaffold
            }//End ZebraCrosspathsTheme
        }//End setContent
    }//End Override fun onCreate
}//End Class MainActivity

@Composable
fun navBar(items: List<String>, icons: List<ImageVector>, selected: Int, onStateChanged: (Int) -> Unit) {
    NavigationBar {
        items.forEachIndexed { index, item ->
            NavigationBarItem(selected = index == selected, onClick = { onStateChanged(index)}, icon = {
                Column {
                    Icon(imageVector = icons[index], contentDescription = item)
                    Text(item)
                }//End Column
            })//End NavigationBarItem
        }//End Items.forEachIndexed
    }//End NavigationBar
}//End fun navBar


