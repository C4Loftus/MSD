package com.example.icetomeetyou.databases

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class User(
    @PrimaryKey(autoGenerate = true)
    val userId: Int = 0,

    val name: String,
    val description: String,

    val musicGenres: List<String>,
    val favouriteArtists: List<String>,

    val sports: List<String>,
    val favouriteTeams: List<String>,

    val movieGenres: List<String>,
    val favouriteMovies: List<String>,

    val gameGenres: List<String>,
    val favouriteGames: List<String>,

    val interests: String = ""
)//End data class user