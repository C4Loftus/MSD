package com.example.icetomeetyou

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import java.io.File
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

@Composable
fun ProfilePicture(modifier: Modifier = Modifier.Companion) {
    val context = LocalContext.current

    // location of chosen image, saved in apps private storage
    val imageFile = remember { File(context.filesDir, "profile_picture.jpg") }

    // counts number of time the profile picture has changed
    //0 means no picture yet
    //1 or more means a picture exists
    var version by remember { mutableIntStateOf(if (imageFile.exists()) 1 else 0) }

    // opens the users system photo picker and handles the result
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        //if the user exits without choosing a photo, uri = null
        if (uri != null) {
            //copies the chosen image into the app's own storag
            context.contentResolver.openInputStream(uri)?.use { input ->
                imageFile.outputStream().use { output -> input.copyTo(output) }
            }//end copy
            version++ //promts image to reload
        }//End if
    }//end picker

    //launches the picker. only displays photos
    fun pickImage() {
        picker.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
        )
    }//End pickImage

    Column(
        modifier = modifier.fillMaxWidth().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        //circular frame for the picture, tap to change it
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(CircleShape)
                .background(Color.Gray)
                .clickable { pickImage() },
            contentAlignment = Alignment.Center
        ) {
            if (version > 0) {
                //shows the saved photo, cropped to fill the circle
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(imageFile)
                        .memoryCacheKey("profile_picture_$version") //new key = fresh load
                        .build(),
                    contentDescription = "Profile picture",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )//end AsyncImage
            } else {
                //placeholder for when no profile picture has been selected
                Icon(
                    imageVector = person,
                    contentDescription = "Default profile picture",
                    modifier = Modifier.size(64.dp),
                    tint = Color.White
                )//end Icon
            }//end if/else
        }//end Box

        TextButton(onClick = { pickImage() }) {
            Text(if (version > 0) "Change photo" else "Upload photo")
        }//end TextButton
    }//ebd Column
}//end ProfilePicture